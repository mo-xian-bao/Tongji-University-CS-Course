`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/11/11 15:42:05
// Design Name: 
// Module Name: alu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module alu(
input [31:0] a, //32 λ���룬������ 1
input [31:0] b, //32 λ���룬������ 2
input [3:0] aluc, //4 λ���룬���� alu �Ĳ���
output reg [31:0] r, //32 λ������� a��b ���� aluc ָ���Ĳ�������
output reg zero, //0 ��־λ
output reg carry, // ��λ��־λ
output reg negative, // ������־λ
output reg overflow // �����־λ
);
integer i;

always @*
begin
    if(aluc == 4'b0000)
    begin
        r = a+b;
        if(r == 0) zero = 1;
        else zero = 0;
        if(((a[31]==1||b[31]==1)&&r[31]==0)||(a[31]==1&&b[31]==1)) carry = 1;
        else carry = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
    
    else if(aluc==4'b0010)
    begin
        r = a + b;
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
        if(r[31]!=a[31] && r[31]!=b[31]) overflow=1;
        else overflow=0;
    end
    
    else if(aluc==4'b0001)
    begin
        r = a - b;
        if (r == 0) zero = 1;
        else zero = 0;
        if (a < b) carry = 1;
        else carry = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
    
    else if(aluc==4'b0011)
    begin
        r = a - b;
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
        if (r[31]!=a[31]&&r[31]==b[31]) overflow=1;
        else overflow = 0;
    end
    
    else if(aluc==4'b0100)
    begin
        r = a & b;
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
    
    else if(aluc==4'b0101)
    begin
        r = a | b;
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
    
    else if(aluc==4'b0110)
    begin
        r = a ^ b;
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
    
    else if(aluc==4'b0111)
    begin
        r = ~(a | b);
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
    
    else if(aluc==4'b1000||aluc==4'b1001)
    begin
        r = {b[15:0], 16'b0};
        if(r==0) zero=1;
        else zero=0; 
        if(r[31]==1) negative=1;
        else negative=0;
    end
    
    else if(aluc==4'b1011)
    begin
        if ($signed (a) < $signed(b))  r = 1;
        else r=0;
        if (a == b) zero = 1;
        else zero = 0;
        if($signed (a)<$signed(b)) negative = 1;
        else negative = 0;    
    end
    
    else if(aluc==4'b1010)
    begin
        r = (a < b) ? 1 : 0;
        if (a == b) zero = 1;
        else zero = 0;
        if (r[31]==1) negative = 1;
        else negative = 0;
        if(a<b) carry=1;
        else carry=0;
    end
    
    else if(aluc==4'b1100)
    begin
        if(a!=0) carry=b[a-1];
        else carry=0;
        
        if (b[31] == 1) begin 
            r= b >> a;
            for (i = 0; i < a; i = i + 1)
                r[31 - i] = 1;
        end
        else begin 
            r = b >> a; 
            for (i = 0; i < a; i = i + 1)
            r[31 - i] = 0;
        end
                    
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
    
    else if(aluc==4'b1110||aluc==4'b1111)
    begin
        if(a==0) carry=0;
        else carry = b[32-a];
        r = b << a;
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
    
    else if(aluc==4'b1101)
    begin
        if(a!=0) carry=b[a-1];
        else carry=0;
        
        r = b >> a;
        for (i = 0; i < a; i = i + 1)
            r[31 - i] = 0;
                        
        if (r == 0) zero = 1;
        else zero = 0;
        if (r[31] == 1) negative = 1;
        else negative = 0;
    end
end

endmodule
