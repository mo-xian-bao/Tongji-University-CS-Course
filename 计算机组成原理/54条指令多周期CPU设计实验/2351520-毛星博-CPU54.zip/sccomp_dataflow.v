module sccomp_dataflow(
    input clk_in,
    input reset,
    output [31:0] inst, // ָ�����
    output [31:0] pc    // PCֵ���
);

    // �ڲ��ź�����CU��datapath
    wire [31:0] Instr;
    wire [31:0] ACC;
    wire [31:0] PC;  
    wire [31:0] InstOut; // ������ֱ������IMEM��ָ�����
    wire ZF, SF;
    wire [31:0] CP0_status;
    wire MDU_busy;
    
    // �����źŴ�CU��datapath
    wire PC_in, IR_in, ACC_in;
    wire [3:0] ALUc;
    wire [1:0] MDUc;
    wire DM_r, DM_w;
    wire [2:0] byte_out_c;
    wire [3:0] byte_in_ena;
    wire HI_w, LO_w;
    wire M1, M2, M3, M6, M7;
    wire [2:0] M4, M5;
    wire mfc0, mtc0, eret, exception;
    wire [4:0] cause;
    wire MDR_in, EXT_c, Reg_in;
    wire RsReg_in, RtReg_in;
    wire MDU_start;
    wire Latch_PC4_in_M4;
    
    // ʵ�������Ƶ�ԪCU
    CU cu_inst(
        .clk(clk_in),
        .rst(reset),
        .Instr(Instr),
        .ACC(ACC),
        .ZF(ZF),
        .SF(SF),
        .CP0_status(CP0_status),
        .MDU_busy(MDU_busy),
        
        // �����ź����
        .PC_in(PC_in),
        .IR_in(IR_in),
        .ACC_in(ACC_in),
        .ALUc(ALUc),
        .MDUc(MDUc),
        .DM_r(DM_r),
        .DM_w(DM_w),
        .byte_out_c(byte_out_c),
        .byte_in_ena(byte_in_ena),
        .HI_w(HI_w),
        .LO_w(LO_w),
        .M1(M1),
        .M2(M2),
        .M3(M3),
        .M4(M4),
        .M5(M5),
        .M6(M6),
        .M7(M7),
        .mfc0(mfc0),
        .mtc0(mtc0),
        .eret(eret),
        .exception(exception),
        .cause(cause),
        .MDR_in(MDR_in),
        .EXT_c(EXT_c),
        .Reg_in(Reg_in),
        .RsReg_in(RsReg_in),
        .RtReg_in(RtReg_in),
        .MDU_start(MDU_start), 
        .Latch_PC4_in_M4(Latch_PC4_in_M4)
    );
    
    // ʵ��������ͨ·datapath
    datapath sccpu(
        .clk(clk_in),
        .rst(reset),
        
        // �����ź�����
        .PC_in(PC_in),
        .IR_in(IR_in),
        .ACC_in(ACC_in),
        .ALUc(ALUc),
        .MDUc(MDUc),
        .DM_r(DM_r),
        .DM_w(DM_w),
        .byte_out_c(byte_out_c),
        .byte_in_ena(byte_in_ena),
        .HI_w(HI_w),
        .LO_w(LO_w),
        .M1(M1),
        .M2(M2),
        .M3(M3),
        .M4(M4),
        .M5(M5),
        .M6(M6),
        .M7(M7),
        .mfc0(mfc0),
        .mtc0(mtc0),
        .eret(eret),
        .exception(exception),
        .cause(cause),
        .MDR_in(MDR_in),
        .EXT_c(EXT_c),
        .Reg_in(Reg_in),
        .RsReg_in(RsReg_in),
        .RtReg_in(RtReg_in),
        .MDU_start(MDU_start),
        .Latch_PC4_in_M4(Latch_PC4_in_M4),
        
        // ״̬�ź����
        .Instr(Instr),
        .ACC(ACC),
        .ZF(ZF),
        .SF(SF),
        .CP0_status(CP0_status),
        .MDU_busy(MDU_busy),
        .PC(PC),  // �����ǰPCֵ
        .InstOut(InstOut)  // ������ֱ������IMEM��ָ�����
    );
    
    // ����ź�����
    assign inst = InstOut;  // ��ֱ������IMEM��ָ���ź����ӵ����
    assign pc = PC;  // ��PCֵ���ӵ����

endmodule
