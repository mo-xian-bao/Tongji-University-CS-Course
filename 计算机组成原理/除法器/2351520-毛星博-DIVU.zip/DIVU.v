`timescale 1ns / 1ps

module DIVU(
    input [31:0] dividend,      // 被除�?
    input [31:0] divisor,       // 除数
    input start,                // 启动除法运算
    input clock,
    input reset,
    output [31:0] q,        // �?
    output [31:0] r,        // 余数
    output reg busy             // 除法器忙标志�?
);

    wire ready;
    reg [5:0] count;           // 计数器，用于32位运算需�?6�?
    reg [31:0] reg_q;          // 商寄存器
    reg [31:0] reg_r;          // 余数寄存�?
    reg [31:0] reg_b;          // 除数寄存�?
    reg busy2, r_sign;         // busy2用于产生ready信号，r_sign表示余数符号

    // ready信号生成
    assign ready = ~busy & busy2;

    // 加减法器，根据r_sign选择加法或减�?
    wire [32:0] sub_add = r_sign ? 
                          ({reg_r, reg_q[31]} + {1'b0, reg_b}) : 
                          ({reg_r, reg_q[31]} - {1'b0, reg_b});

    // �?终余数计�?
    assign r = r_sign ? reg_r + reg_b : reg_r;
    // �?终商输出
    assign q = reg_q;

    // 主状态控�?
    always @(posedge clock or posedge reset) begin
        if (reset == 1) begin
            // 复位状�??
            count <= 6'b0;
            busy <= 0;
            busy2 <= 0;
        end else begin
            busy2 <= busy;
            if (start) begin
                // �?始除法运算，初始化各寄存�?
                reg_r <= 32'b0;
                r_sign <= 0;
                reg_q <= dividend;
                reg_b <= divisor;
                count <= 6'b0;
                busy <= 1'b1;
            end else if (busy) begin
                // 循环操作
                reg_r <= sub_add[31:0];     // 更新部分余数
                r_sign <= sub_add[32];      // 更新符号位，决定下次是加还是�?
                reg_q <= {reg_q[30:0], ~sub_add[32]}; // 更新�?
                count <= count + 6'b1;      // 计数器加1
                if (count == 6'h1F)         // 32位运算完�?
                    busy <= 0;              // 清除忙标�?
            end
        end
    end

endmodule
