`timescale 1ns / 1ps

module DIV(
    input [31:0] dividend,      // 被除数
    input [31:0] divisor,       // 除数
    input start,                // 启动除法运算
    input clock,
    input reset,
    output [31:0] q,           // 商
    output [31:0] r,           // 余数
    output reg busy            // 除法器忙标志位
);

    wire ready;
    reg [5:0] count;           // 计数器，用于32位运算需要6位
    reg [31:0] reg_q;          // 商寄存器
    reg [31:0] reg_r;          // 余数寄存器
    reg [31:0] reg_b;          // 除数寄存器
    reg busy2, r_sign;         // busy2用于产生ready信号，r_sign表示余数符号
    reg q_sign;                // 商的符号
    reg dividend_sign;         // 被除数的符号

    // ready信号生成
    assign ready = ~busy & busy2;

    // 加减法器，根据r_sign选择加法或减法
    wire [32:0] sub_add = r_sign ? 
                          ({reg_r, reg_q[31]} + {1'b0, reg_b}) : 
                          ({reg_r, reg_q[31]} - {1'b0, reg_b});

    // 余数恢复和最终结果计算
    wire need_restore = r_sign;
    wire [31:0] restored_r = need_restore ?
        reg_r + reg_b :
        reg_r;

    
    // 最终输出，根据符号确定最终的余数和商
    assign r = dividend_sign ? -restored_r : restored_r;
    assign q = q_sign ? -reg_q : reg_q;

    // 主状态控制
    always @(posedge clock or posedge reset) begin
        if (reset == 1) begin
            // 复位状态
            count <= 6'b0;
            busy <= 0;
            busy2 <= 0;
        end else begin
            busy2 <= busy;
            if (start) begin
                // 开始除法运算，初始化各寄存器
                // 保存符号信息
                dividend_sign <= dividend[31];
                q_sign <= dividend[31] ^ divisor[31];
                
                // 初始化除法运算
                reg_r <= 32'b0;
                r_sign <= 0;
                reg_q <= dividend[31] ? -dividend : dividend;
                reg_b <= divisor[31] ? -divisor : divisor;
                count <= 6'b0;
                busy <= 1'b1;
            end else if (busy) begin
                // 循环操作
                reg_r <= sub_add[31:0];     // 更新部分余数
                r_sign <= sub_add[32];      // 更新符号位，决定下次是加还是减
                reg_q <= {reg_q[30:0], ~sub_add[32]}; // 更新商
                count <= count + 6'b1;      // 计数器加1
                if (count == 6'h1F)         // 32位运算完成
                    busy <= 0;              // 清除忙标志
            end
        end
    end

endmodule
