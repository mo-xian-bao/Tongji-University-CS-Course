module RegFile(
    input clk, // ʱ���ź�
    input rst, // ��λ�ź�
    input ena, // ʹ���ź�
    input we, // дʹ���ź�
    input [4:0] Rdc, // Ŀ��Ĵ���
    input [4:0] Rsc, // Դ�Ĵ���1
    input [4:0] Rtc, // Դ�Ĵ���2
    input [31:0] Rd, // ��������
    output [31:0] Rs, // Դ�Ĵ���1�������
    output [31:0] Rt // Դ�Ĵ���2�������
);

reg [31:0] array_reg [31:0]; // 32��32λ�Ĵ���
integer i;

//�첽��ȡ
assign Rs = (ena) ? array_reg[Rsc] : 32'bz;
assign Rt = (ena) ? array_reg[Rtc] : 32'bz;
//assign regs_debug = regs;

//ͬ��д��
always @(posedge clk or posedge rst) begin // ʱ�������ػ�λ������
    if (ena && rst) begin // ��λ
        array_reg[0] <= 32'h00000000;
        array_reg[1] <= 32'h00000000;
        array_reg[2] <= 32'h00000000;
        array_reg[3] <= 32'h00000000;
        array_reg[4] <= 32'h00000000;
        array_reg[5] <= 32'h00000000;
        array_reg[6] <= 32'h00000000;
        array_reg[7] <= 32'h00000000;
        array_reg[8] <= 32'h00000000;
        array_reg[9] <= 32'h00000000;
        array_reg[10] <= 32'h00000000;
        array_reg[11] <= 32'h00000000;
        array_reg[12] <= 32'h00000000;
        array_reg[13] <= 32'h00000000;
        array_reg[14] <= 32'h00000000;
        array_reg[15] <= 32'h00000000;
        array_reg[16] <= 32'h00000000;
        array_reg[17] <= 32'h00000000;
        array_reg[18] <= 32'h00000000;
        array_reg[19] <= 32'h00000000;
        array_reg[20] <= 32'h00000000;
        array_reg[21] <= 32'h00000000;
        array_reg[22] <= 32'h00000000;
        array_reg[23] <= 32'h00000000;
        array_reg[24] <= 32'h00000000;
        array_reg[25] <= 32'h00000000;
        array_reg[26] <= 32'h00000000;
        array_reg[27] <= 32'h00000000;
        array_reg[28] <= 32'h00000000;
        array_reg[29] <= 32'h00000000;
        array_reg[30] <= 32'h00000000;
        array_reg[31] <= 32'h00000000;
    end
    else begin 
        if (ena && we && Rdc != 0) // д�루0�żĴ�������д�룩
            array_reg[Rdc] <= Rd;
    end
end

endmodule