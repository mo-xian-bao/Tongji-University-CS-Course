.text
main:
	#$2-$6������������
	addi $2, $zero, 6
    addi $3, $zero, 6
    addi $4, $zero, 6
   	addi $5, $zero, 6
    addi $6, $zero, 6

# ��һ�ֱȽ�
round1_cmp1:
    slt $t0, $3, $2 # ���$3 < $2����$t0=1
    beq $t0, $zero, round1_cmp2 # �������Ҫ����������
    # $3>=$2,�������ߵ�ֵ
    add $t1, $3, $zero
    add $3, $2, $zero
    add $2, $t1, $zero
    
round1_cmp2:
    slt $t0, $4, $3
    beq $t0, $zero, round1_cmp3
    add $t1, $4, $zero
    add $4, $3, $zero
    add $3, $t1, $zero
    
round1_cmp3:
    slt $t0, $5, $4
    beq $t0, $zero, round1_cmp4
    add $t1, $5, $zero
    add $5, $4, $zero
    add $4, $t1, $zero
    
round1_cmp4:
    slt $t0, $6, $5
    beq $t0, $zero, round2_cmp1
    add $t1, $6, $zero
    add $6, $5, $zero
    add $5, $t1, $zero
    
# �ڶ��ֱȽ�
round2_cmp1:
    slt $t0, $3, $2
    beq $t0, $zero, round2_cmp2
    add $t1, $3, $zero
    add $3, $2, $zero
    add $2, $t1, $zero
    
round2_cmp2:
    slt $t0, $4, $3
    beq $t0, $zero, round2_cmp3
    add $t1, $4, $zero
    add $4, $3, $zero
    add $3, $t1, $zero
    
round2_cmp3:
    slt $t0, $5, $4
    beq $t0, $zero, round3_cmp1
    add $t1, $5, $zero
    add $5, $4, $zero
    add $4, $t1, $zero
    
# �����ֱȽ�
round3_cmp1:
    slt $t0, $3, $2
    beq $t0, $zero, round3_cmp2
    add $t1, $3, $zero
    add $3, $2, $zero
    add $2, $t1, $zero
    
round3_cmp2:
    slt $t0, $4, $3
    beq $t0, $zero, round4_cmp1
    add $t1, $4, $zero
    add $4, $3, $zero
    add $3, $t1, $zero
    
# �����ֱȽ�
round4_cmp1:
    slt $t0, $3, $2
    beq $t0, $zero, end_program
    add $t1, $3, $zero
    add $3, $2, $zero
    add $2, $t1, $zero
    
end_program:
    #addi $v0, $zero, 10
    #syscall
