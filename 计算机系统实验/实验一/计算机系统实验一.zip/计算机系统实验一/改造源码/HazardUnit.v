`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: HazardUnit
// Description: ð�ռ�ⵥԪ - ��������ð�ռ��ͷ�֧�ж�
//              1. Load-Useð�ռ��
//              2. MDUð�ռ��
//              3. ��֧����ð�ռ��
//              4. ��ǰ��֧�жϣ�ID�׶Σ�
//////////////////////////////////////////////////////////////////////////////////

module HazardUnit(
    // ==================== ID�׶��ź� ====================
    input [4:0] ID_rs,
    input [4:0] ID_rt,
    input [31:0] ID_rs_data_fwd,     // ǰ�ƺ��rs����
    input [31:0] ID_rt_data_fwd,     // ǰ�ƺ��rt����
    input ID_is_branch,
    input [2:0] ID_branch_type,      // ��֧����
    input ID_is_mdu_op,              // �Ƿ�ΪMDU����
    input ID_is_mfhi,
    input ID_is_mflo,
    
    // ==================== ID/EX�׶��ź� ====================
    input [4:0] ID_EX_write_reg,
    input ID_EX_reg_write,
    input ID_EX_mem_read,
    input ID_EX_is_mfc0,
    input ID_EX_is_mdu_op,           // EX�׶��Ƿ�ΪMDU���������ڼ��mult��������
    
    // ==================== EX/MEM�׶��ź� ====================
    input [4:0] EX_MEM_write_reg,
    input EX_MEM_reg_write,
    input EX_MEM_mem_read,
    input EX_MEM_is_mfc0,
    
    // ==================== MDU�ź� ====================
    input MDU_busy,
    
    // ==================== ����ź� ====================
    output stall,
    output branch_taken
);

    // ==================== Load-Useð�ռ�� ====================
    wire load_use_hazard = (ID_EX_mem_read || ID_EX_is_mfc0) && (ID_EX_write_reg != 5'b0) &&
                           ((ID_EX_write_reg == ID_rs) || (ID_EX_write_reg == ID_rt));
    
    // ==================== MDUð�ռ�� ====================
    // ������MDU��ð��
    wire mdu_hazard = 1'b0;
    
    // ==================== ��֧����ð�ռ�� ====================
    wire branch_hazard = ID_is_branch && (
        // ID/EX�׶���д�Ĵ�����ָ��
        (ID_EX_reg_write && (ID_EX_write_reg != 5'b0) &&
         ((ID_EX_write_reg == ID_rs) || (ID_EX_write_reg == ID_rt))) ||
        // EX/MEM�׶���LOADָ��
        (EX_MEM_reg_write && (EX_MEM_write_reg != 5'b0) && (EX_MEM_mem_read || EX_MEM_is_mfc0) &&
         ((EX_MEM_write_reg == ID_rs) || (EX_MEM_write_reg == ID_rt)))
    );
    
    // ==================== Stall�ź� ====================
    assign stall = load_use_hazard || mdu_hazard || branch_hazard;
    
    // ==================== ��֧�ж� ====================
    wire br_eq  = (ID_rs_data_fwd == ID_rt_data_fwd);
    wire br_gez = !ID_rs_data_fwd[31];                          // rs >= 0
    wire br_gtz = !ID_rs_data_fwd[31] && (ID_rs_data_fwd != 0); // rs > 0
    wire br_lez = ID_rs_data_fwd[31] || (ID_rs_data_fwd == 0);  // rs <= 0
    wire br_ltz = ID_rs_data_fwd[31];                           // rs < 0
    
    assign branch_taken = !stall && ID_is_branch && (
        (ID_branch_type == 3'b000 && br_eq)  ||  // BEQ
        (ID_branch_type == 3'b001 && !br_eq) ||  // BNE
        (ID_branch_type == 3'b010 && br_gez) ||  // BGEZ/BGEZAL
        (ID_branch_type == 3'b011 && br_gtz) ||  // BGTZ
        (ID_branch_type == 3'b100 && br_lez) ||  // BLEZ
        (ID_branch_type == 3'b101 && br_ltz)     // BLTZ/BLTZAL
    );

endmodule
